import math
# самостоятельная работа №2 и №3
# вариант 8

x = input("Введите x - ")
try:
    x = float(x)
except ValueError:
    print("Вы ввели не число!")

y = input("Введите y - ")
try:
    y = float(y)
except ValueError:
    print("Вы ввели не число!")

z = input("Введите z - ")
try:
    z = float(z)
except ValueError:
    print("Вы ввели не число!")

if math.atan(x) + math.atan(z) == 0:
    print("Вы ввели не те числа x и z! Делить на ноль нельзя!")


φ = (math.pow(math.e, abs(x-y)) * math.pow(abs(x-y), x+y)) / (math.atan(x) + math.atan(z)) + math.pow(math.pow(x, 6) + math.pow(math.log1p(y), 2), 1/3)

print("φ =", φ)






