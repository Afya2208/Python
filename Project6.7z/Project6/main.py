# вариант 10
# задание на строки
c = input("Введите символ")
s = input("Введите первую строку")
s0 = input("Введите вторую строку")
start = s.find(c)
copy = ''
continie = s[start+1:s.__len__()].find(c)
while continie > -1:
    copy += s[0+start:continie]
    continie = s[start + 1:s.__len__()].find(c)
    start = continie






# задание на списки - сделано
i = 0
A = []
while i < 16:
    A.append(input("введите число в список - "))
    i += 1
index = A.index(max(A))
B = A[0:index]
B.reverse()
print(B)

