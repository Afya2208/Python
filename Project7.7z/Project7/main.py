
import random

def gameTask8():
    c = 0
    rand = random.randint(0, 100)
    print(rand)
    while c < 10:
        a = int(input("Введи число - "))
        if a == rand:
            return "Ты нашел число!"
        elif a > rand:
            c += 1
            print("Оно больше")
        else:
            c +=1
            print("Оно меньше")
    else:
        return f"Ты не отгадал!\nЗадано число - {rand}"

def Task3(number):
    summ = 0
    proz = 1
    print(f"Число - {number}")
    while number > 0:
        num = number % 10
        summ += num
        proz *= num
        number //= 10
    return f"Произведение цифр = {proz}\nСумма цифр = {summ}"

def Task2(number):
    count4 = 0
    countNOT4 = 0
    print(f"Число - {number}")
    while number > 0:
        num = number % 10
        if num % 2 == 0:
            count4 += 1
        else:
            countNOT4 += 1
        number //= 10
    else:
        return f"Четных цифр - {count4}\nНечетных цифр - {countNOT4}"

def Task5(number):
    result = 1
    while number > 0:
        result *= number
        number -= 1
    return result

def Task7(number):
    c = 1
    a = 0
    result = ""
    while number > 0:
        a += c
        c = a
        result += str(a) + " "
        number -= 1
    return result

print("....Задание 8....")
print(gameTask8())
print("....Задание 3....")
print(Task3(325))
print("....Задание 2....")
print(Task2(34560))
print("....Задание 5....")
print(Task5(3))
print("....Задание 7....")
print(Task7(6))





