import math

nameOfPerson = input("Ваше имя ")
surnameOfPerson = input("Ваша фамилия ")
print("Имя:", nameOfPerson)
print("Фамилия:", surnameOfPerson)

isAlive = False
isWork = True
print(isAlive, isWork)

My_num1 = 0b11001111010
My_num2 = 0o76123777
My_num3 = 0xAFDF23
print(My_num1, My_num2, My_num3)

My_height = 66.2
print(My_height)

name = input("Введите имя питомца ")
surname = input("Введите название его любимой игрушки ")
age = input("Введите возраст вашего питомца (сколько полных лет) ")
weight = input("Введите вес вашего питомца в килограммах ")
height = input("Введите рост вашего питомца в сантиметрах ")
lengthOfTail = input("Введите длину хвоста вашего питомца в сантиметрах ")
print("Имя вашего питомца -",name, "\tЕго любимая игрушка -", surname, "\tЕго возраст -", age)
print("Его рост -", height, "\tЕго вес - ", weight)

print("Длина его хвоста -", lengthOfTail)

# Индивидуальное задание вариант 10
a =int( input("Введите угол a - "))

z1 = (1-2*(math.sin(a)**2))/(1+math.sin(2*a))
z2 = (1-math.tan(a))/(1+math.tan(a))
print("z1 =", z1, "\nz2 =", z2)
print(f'Z1 = {z1} Z2 = {z2}')
