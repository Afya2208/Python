def change(lst):
    lst[0],lst[len(lst)-1] = lst[len(lst)-1], lst[0]
    for a in lst:
        print(a)
yy = [1,2,4,5,7,8,0,0]
change(yy)
def to_list(*a):
    count = len(a)
    listik = []
    while count>0:
        listik.append(a[len(a)-count])
        count-=1
        for ab in listik:
            print(ab)
to_list(yy)
def useless(lst):
    max = lst[0]
    count = len(lst)
    while count>0:
        if max < lst[len(lst)-count]: max = lst[len(lst)-count]
        count-=1

    print(max / len(lst))
useless(yy)
def all_eq(*lst):
    max_len =