a = "123456789"
import math
print(a[2], a[4])
print(a[4:7])
print(a[-7], a[-5])
print(a[-5:-2])

ints = [1,3,3,5,1,8]
print(ints[0], ints[ints.__len__()-1])
try:

    cat1 = int(input())
    cat2 = int(input())
    gip = math.sqrt(cat2**2+cat1**2)
    print("площадь - ", cat2*cat1/2, "периметр - ", cat2+cat1+gip)
except ValueError:
    print("Надо число")