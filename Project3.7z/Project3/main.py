import math

language = "germas"
daytime = "mornings"
if language == "english":
    print("ENGLISH")
    if daytime == "morning":
        print("MORNING")
    else:
        print("NOT MORNING")
elif language == "german":
    print("GERMAN")
else:
    print("NOTHING")
print("END")
# ВАРИАНТ 10
z = int(input("Введите z - "))
if z >= 1:
    x = z-1
else:
    x = z**2+1
y = (math.e**(math.sin(x)**3)+math.log1p(x+1))/x**0.5
print(y)

x = int(input("Введите x - "))
y = int(input("Введите y - "))
z = int(input("Введите z - "))
if x > y:
    max_x_and_y = x
elif x < y:
    max_x_and_y = y
else:
    max_x_and_y = y

if z > y:
    max_z_and_y = z
elif z < y:
    max_z_and_y = y
else:
    max_z_and_y = y

if max_x_and_y > max_z_and_y:
    max_big = max_x_and_y
elif max_x_and_y < max_z_and_y:
    max_big = max_z_and_y
else:
    max_big = max_z_and_y

if x<z or x<y:
    if x<y or x<z:
        min = x
    else:
        min = x
elif y<z or y<x:
    if y<x or y<z:
        min = y
    else:
        min = y
elif z<y or z<x:
    if z<x or z<y:
        min = z
    else:
        min = z
else:
    min = x
m = max_big/min
print(m)