import telebot
botik = telebot.TeleBot("5995816261:AAHFVPYcHcrkF6lS3GKLnr_n99IiWzJElfg")
@botik.message_handler(commands=["start"])

def start(m, res=False):
    botik.send_message(m.chat.id, 'ЗДАРОВА! Нажми 1, если хочешь радомную столицу и её страну \nНажми 2, чтобы добавить столицу\nНажми 3, чтобы удалить столицу')
@botik.message_handler(content_types=["text"])

def handle_text(message):

    botik.send_message(message.chat.id, 'Вы написали: ' + message.text)
botik.polling(none_stop=True, interval=0)
@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == '1':
        botik.send_message(message.chat.id, 'Я зарандомил эту столицу: ' + randomi())
    if message.text == '2':
        botik.send_message(message.chat.id, 'Напишите столицу и её страну! ')
        botik.register_next_step_handler(message,AddElement)
    if message.text == '3':
        botik.send_message(message.chat.id, 'Напишите цвет, который надо удалить')
        botik.register_next_step_handler(message, RemoveElement)
import random
list = ["Абхазия - Сухуми (Сухум)","Австралия - Канберра","Австрия - Вена","Азербайджан - Баку","Албания - Тирана","Алжир - Алжир","Ангола - Луанда",
"Андорра - Андорра-ла-Велья","Антигуа и Барбуда - Сент-Джонс","Аргентина - Буэнос-Айрес","Армения - Ереван","Афганистан - Кабул","Багамские острова - Нассау",
"Бангладеш - Дакка","Барбадос - Бриджтаун","Бахрейн - Манама","Белиз - Бельмопан","Беларусь - Минск","Бельгия - Брюссель","Бенин - Порто-Ново",
"Болгария - София","Боливия - Ла-Пас","Босния и Герцеговина - Сараево","Ботсвана - Габороне","Бразилия - Бразилиа","Бруней - Бандар-Сери-Бегаван",
"Буркина-Фасо - Уагадугу","Великобритания - Лондон","Венгрия - Будапешт",
"Венесуэла - Каракас"]
listreturn = []
print(list.__len__())
def randomi():
    count = random.randint(0,30)
    return list[count]
def newElement():