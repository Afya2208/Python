
import math

# самостоятельная №4
# вариант 8

a = 8
b = 15
n = 10
x = a
h = (b-a)/n
print("x     F(x)\n")
while x <= b:
    f = math.log1p(x - 5) + 6
    print(f"{x}     {f}\n")
    x += h